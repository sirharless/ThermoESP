package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TelemetryPoint
import com.example.data.model.TimeRangeFilter
import com.example.data.repository.EspTelemetryRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ThermoESP", appName)
    }

    @Test
    fun `test statistics computation`() {
        val repo = EspTelemetryRepository()
        val p1 = TelemetryPoint(
            timestamp = 1000L,
            temperature = 22.0,
            voltage = 3.80,
            batteryPercent = 70,
            isCharging = false,
            dateTimeStr = "30.09.2026 12:00:00"
        )
        val p2 = TelemetryPoint(
            timestamp = 1600L,
            temperature = 26.0,
            voltage = 3.90,
            batteryPercent = 80,
            isCharging = false,
            dateTimeStr = "30.09.2026 12:10:00"
        )

        val stats = repo.computeStatistics(listOf(p1, p2))
        assertEquals(22.0, stats.minTemp, 0.01)
        assertEquals(26.0, stats.maxTemp, 0.01)
        assertEquals(24.0, stats.avgTemp, 0.01)
        assertEquals(4.0, stats.tempDelta, 0.01)
        assertEquals(2, stats.totalCount)
    }

    @Test
    fun `test all 21 time range filters exist`() {
        val filters = TimeRangeFilter.values()
        assertTrue(filters.size >= 21)
        assertNotNull(TimeRangeFilter.valueOf("THREE_HOURS"))
        assertNotNull(TimeRangeFilter.valueOf("SIX_HOURS"))
        assertNotNull(TimeRangeFilter.valueOf("TWELVE_HOURS"))
        assertNotNull(TimeRangeFilter.valueOf("ONE_DAY"))
        assertNotNull(TimeRangeFilter.valueOf("THREE_DAYS"))
        assertNotNull(TimeRangeFilter.valueOf("ONE_WEEK"))
        assertNotNull(TimeRangeFilter.valueOf("TWO_WEEKS"))
        assertNotNull(TimeRangeFilter.valueOf("THREE_WEEKS"))
        assertNotNull(TimeRangeFilter.valueOf("ONE_MONTH"))
        assertNotNull(TimeRangeFilter.valueOf("ELEVEN_MONTHS"))
        assertNotNull(TimeRangeFilter.valueOf("ONE_YEAR"))
    }
}
