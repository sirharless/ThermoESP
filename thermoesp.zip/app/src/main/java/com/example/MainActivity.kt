package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.NavigationTab
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeveloperScreen
import com.example.ui.theme.BatteryGreen
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDarkBackground
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.HeatOrange
import com.example.ui.theme.HeatRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                ThermoEspApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThermoEspApp(viewModel: MainViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.errorMessage) {
        state.errorMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Handle back press if on secondary tabs
    if (state.activeTab != NavigationTab.DASHBOARD) {
        BackHandler {
            viewModel.setTab(NavigationTab.DASHBOARD)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CyberDarkBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberTeal.copy(alpha = 0.2f))
                                .border(1.dp, CyberTeal.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sensors,
                                contentDescription = null,
                                tint = CyberTeal,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "ThermoESP",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (state.guncel.isFaulty) HeatRed.copy(alpha = 0.2f) else BatteryGreen.copy(alpha = 0.2f))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = if (state.guncel.isFaulty) "HATA" else "CANLI",
                                        color = if (state.guncel.isFaulty) HeatRed else BatteryGreen,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Text(
                                text = "ESP32-C3 Sıcaklık & Pil Takibi",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshData() },
                        modifier = Modifier.testTag("top_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Yenile",
                            tint = CyberTeal
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberDarkBackground,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav")
            ) {
                // Dashboard Tab
                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.DASHBOARD,
                    onClick = { viewModel.setTab(NavigationTab.DASHBOARD) },
                    icon = {
                        Icon(
                            imageVector = if (state.activeTab == NavigationTab.DASHBOARD) Icons.Default.Sensors else Icons.Outlined.Sensors,
                            contentDescription = "Gösterge"
                        )
                    },
                    label = { Text("Gösterge", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberTeal,
                        selectedTextColor = CyberTeal,
                        indicatorColor = CyberTeal.copy(alpha = 0.18f),
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                // Analytics & Graphs Tab
                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.ANALYTICS,
                    onClick = { viewModel.setTab(NavigationTab.ANALYTICS) },
                    icon = {
                        Icon(
                            imageVector = if (state.activeTab == NavigationTab.ANALYTICS) Icons.Default.ShowChart else Icons.Outlined.ShowChart,
                            contentDescription = "Grafikler"
                        )
                    },
                    label = { Text("Grafikler", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = HeatOrange,
                        selectedTextColor = HeatOrange,
                        indicatorColor = HeatOrange.copy(alpha = 0.18f),
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                // Developer & Diagnostics Tab
                NavigationBarItem(
                    selected = state.activeTab == NavigationTab.DEVELOPER,
                    onClick = { viewModel.setTab(NavigationTab.DEVELOPER) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (state.hatalar.isNotEmpty()) {
                                    Badge(
                                        containerColor = HeatRed,
                                        contentColor = Color.White
                                    ) {
                                        Text(text = "${state.hatalar.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (state.activeTab == NavigationTab.DEVELOPER) Icons.Default.DeveloperMode else Icons.Outlined.DeveloperMode,
                                contentDescription = "Teşhis"
                            )
                        }
                    },
                    label = { Text("Teşhis & Dev", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberTeal,
                        selectedTextColor = CyberTeal,
                        indicatorColor = CyberTeal.copy(alpha = 0.18f),
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (state.activeTab) {
                NavigationTab.DASHBOARD -> {
                    DashboardScreen(
                        state = state,
                        onNavigateTab = { viewModel.setTab(it) },
                        onPointInspected = { viewModel.setInspectedPoint(it) },
                        onRefresh = { viewModel.refreshData() }
                    )
                }

                NavigationTab.ANALYTICS -> {
                    AnalyticsScreen(
                        state = state,
                        onFilterSelected = { viewModel.setTimeFilter(it) },
                        onMetricSelected = { viewModel.setChartMetric(it) },
                        onPointInspected = { viewModel.setInspectedPoint(it) }
                    )
                }

                NavigationTab.DEVELOPER -> {
                    DeveloperScreen(
                        state = state,
                        onTestEndpoint = { viewModel.testEndpoint(it) },
                        onToggleSimulation = { viewModel.toggleSimulationMode(it) },
                        onUpdateConnection = { url, token -> viewModel.updateConnectionSettings(url, token) },
                        onResetConnection = { viewModel.resetConnectionSettings() },
                        onSetAutoRefresh = { viewModel.setAutoRefreshInterval(it) }
                    )
                }
            }
        }
    }
}
