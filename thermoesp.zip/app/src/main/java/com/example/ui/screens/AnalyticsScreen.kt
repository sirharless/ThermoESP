package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryPoint
import com.example.data.model.TimeRangeFilter
import com.example.ui.ChartMetricType
import com.example.ui.MainUiState
import com.example.ui.components.SmoothTelemetryChart
import com.example.ui.components.TimeRangeSelector
import com.example.ui.theme.BatteryCharging
import com.example.ui.theme.BatteryGreen
import com.example.ui.theme.ChartMinPoint
import com.example.ui.theme.ChartPeakPoint
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDarkBackground
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.HeatOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun AnalyticsScreen(
    state: MainUiState,
    onFilterSelected: (TimeRangeFilter) -> Unit,
    onMetricSelected: (ChartMetricType) -> Unit,
    onPointInspected: (TelemetryPoint?) -> Unit,
    modifier: Modifier = Modifier
) {
    var showLogList by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // Metric Toggle Tabs: Temperature vs Battery
            val metrics = listOf(
                Pair(ChartMetricType.TEMPERATURE, "Sıcaklık Eğrisi (°C)"),
                Pair(ChartMetricType.BATTERY, "Pil Deşarj & Voltaj (V)")
            )
            val selectedIndex = if (state.selectedMetric == ChartMetricType.TEMPERATURE) 0 else 1

            TabRow(
                selectedTabIndex = selectedIndex,
                containerColor = CyberSurfaceCard,
                contentColor = CyberTeal,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                        color = if (state.selectedMetric == ChartMetricType.TEMPERATURE) HeatOrange else CyberTeal
                    )
                }
            ) {
                metrics.forEachIndexed { index, (type, label) ->
                    val isSelected = selectedIndex == index
                    Tab(
                        selected = isSelected,
                        onClick = { onMetricSelected(type) },
                        modifier = Modifier.testTag("metric_tab_$index"),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (type == ChartMetricType.TEMPERATURE) Icons.Default.Thermostat else Icons.Default.BatteryFull,
                                    contentDescription = null,
                                    tint = if (isSelected) (if (type == ChartMetricType.TEMPERATURE) HeatOrange else CyberTeal) else TextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) TextPrimary else TextSecondary
                                )
                            }
                        }
                    )
                }
            }
        }

        // Time Range Filter Selector
        item {
            TimeRangeSelector(
                selectedFilter = state.selectedFilter,
                onFilterSelected = onFilterSelected
            )
        }

        // Interactive Smooth Chart
        item {
            SmoothTelemetryChart(
                points = state.filteredPoints,
                metricType = state.selectedMetric,
                inspectedPoint = state.inspectedPoint,
                onPointInspected = onPointInspected
            )
        }

        // Detailed Statistics Grid Card
        item {
            val stats = state.chartStats
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CyberBorder))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "${state.selectedFilter.label.uppercase()} İSTATİSTİK ÖZETİ",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Row 1: Peak and Min
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Peak Card
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(CyberSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.TrendingUp,
                                        contentDescription = null,
                                        tint = ChartPeakPoint,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "PİK (MAKSİMUM)", color = ChartPeakPoint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (state.selectedMetric == ChartMetricType.TEMPERATURE)
                                        String.format(Locale.US, "%.1f °C", stats.maxTemp)
                                    else
                                        String.format(Locale.US, "%.2f V", stats.maxVoltage),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = stats.maxTempPoint?.dateTimeStr ?: "--",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }
                        }

                        // Min Card
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(CyberSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.TrendingDown,
                                        contentDescription = null,
                                        tint = ChartMinPoint,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "DİP (MİNİMUM)", color = ChartMinPoint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (state.selectedMetric == ChartMetricType.TEMPERATURE)
                                        String.format(Locale.US, "%.1f °C", stats.minTemp)
                                    else
                                        String.format(Locale.US, "%.2f V", stats.minVoltage),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = stats.minTempPoint?.dateTimeStr ?: "--",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Row 2: Average and Delta
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Average
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(CyberSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(text = "ORTALAMA", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (state.selectedMetric == ChartMetricType.TEMPERATURE)
                                        String.format(Locale.US, "%.1f °C", stats.avgTemp)
                                    else
                                        String.format(Locale.US, "%.2f V", stats.avgVoltage),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Dengeli dağılım",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // Delta
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(CyberSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(text = "SALINIM (Δ FARK)", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (state.selectedMetric == ChartMetricType.TEMPERATURE)
                                        String.format(Locale.US, "Δ %.1f °C", stats.tempDelta)
                                    else
                                        String.format(Locale.US, "Δ %.2f V", (stats.maxVoltage - stats.minVoltage).coerceAtLeast(0.0)),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = HeatOrange,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Toplam fark aralığı",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Meta Summary Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberDarkBackground)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kayıt Sayısı: ${stats.totalCount} Adet",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Periyot: 10 dk / Okuma",
                            color = CyberTeal,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Expandable Raw Telemetry Logs Table
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showLogList = !showLogList },
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CyberBorder))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ListAlt,
                            contentDescription = null,
                            tint = CyberTeal,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Ayrıntılı Kayıt Defteri (${state.filteredPoints.size})",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Ölçüm zamanı, derece, voltaj ve pil yüzdesi",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = if (showLogList) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }
            }
        }

        // Expanded Log Items (Latest 100 entries)
        if (showLogList) {
            val listToShow = state.filteredPoints.reversed().take(100)
            itemsIndexed(listToShow) { index, point ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (index % 2 == 0) CyberSurfaceCard else CyberSurfaceElevated)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = point.dateTimeStr,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = String.format(Locale.US, "%.2fV  •  %%%d", point.voltage, point.batteryPercent),
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            if (point.isCharging) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "⚡ Şarjda", color = BatteryCharging, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Text(
                        text = String.format(Locale.US, "%.1f °C", point.temperature),
                        color = HeatOrange,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
