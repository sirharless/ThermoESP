package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryPoint
import com.example.ui.ChartMetricType
import com.example.ui.theme.ChartMinPoint
import com.example.ui.theme.ChartPeakPoint
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.HeatOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SmoothTelemetryChart(
    points: List<TelemetryPoint>,
    metricType: ChartMetricType,
    inspectedPoint: TelemetryPoint?,
    onPointInspected: (TelemetryPoint?) -> Unit,
    modifier: Modifier = Modifier
) {
    if (points.isEmpty()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .height(280.dp),
            colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Bu zaman aralığında veri bulunamadı",
                    color = TextMuted,
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    // Downsample if dataset is very large for buttery 60/120fps smooth rendering
    val renderPoints = remember(points) {
        if (points.size > 200) {
            val step = points.size / 150.0
            val sampled = mutableListOf<TelemetryPoint>()
            var acc = 0.0
            while (acc < points.size) {
                sampled.add(points[acc.toInt()])
                acc += step
            }
            if (sampled.lastOrNull() != points.last()) {
                sampled.add(points.last())
            }
            sampled
        } else {
            points
        }
    }

    val values = remember(renderPoints, metricType) {
        renderPoints.map {
            when (metricType) {
                ChartMetricType.TEMPERATURE -> it.temperature
                ChartMetricType.BATTERY -> it.voltage
            }
        }
    }

    val minVal = remember(values) { (values.minOrNull() ?: 0.0) }
    val maxVal = remember(values) { (values.maxOrNull() ?: 1.0) }
    val valRange = remember(minVal, maxVal) {
        val diff = maxVal - minVal
        if (diff <= 0.001) 1.0 else diff
    }

    // Identify Peak and Min points
    val peakIndex = remember(values) { values.indices.maxByOrNull { values[it] } ?: 0 }
    val minIndex = remember(values) { values.indices.minByOrNull { values[it] } ?: 0 }

    val peakPoint = renderPoints[peakIndex]
    val minPoint = renderPoints[minIndex]

    // Animation progress for chart reveal
    val animationProgress = remember { Animatable(0f) }
    LaunchedEffect(metricType, points.size) {
        animationProgress.snapTo(0f)
        animationProgress.animateTo(1f, animationSpec = tween(durationMillis = 650))
    }

    var touchX by remember { mutableFloatStateOf(-1f) }
    val textMeasurer = rememberTextMeasurer()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("smooth_telemetry_chart_card"),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard),
        shape = RoundedCornerShape(20.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CyberBorder, CyberSurfaceElevated)))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Peak and Min Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Peak Tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(ChartPeakPoint.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "Peak",
                        tint = ChartPeakPoint,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "PEAK: " + when (metricType) {
                            ChartMetricType.TEMPERATURE -> String.format(Locale.US, "%.1f°C", peakPoint.temperature)
                            ChartMetricType.BATTERY -> String.format(Locale.US, "%.2fV (%d%%)", peakPoint.voltage, peakPoint.batteryPercent)
                        },
                        color = ChartPeakPoint,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Min Tag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(ChartMinPoint.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Min",
                        tint = ChartMinPoint,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "MİN: " + when (metricType) {
                            ChartMetricType.TEMPERATURE -> String.format(Locale.US, "%.1f°C", minPoint.temperature)
                            ChartMetricType.BATTERY -> String.format(Locale.US, "%.2fV (%d%%)", minPoint.voltage, minPoint.batteryPercent)
                        },
                        color = ChartMinPoint,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Chart Canvas with Touch Scrubbing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .pointerInput(renderPoints) {
                        detectTapGestures(
                            onPress = { offset ->
                                touchX = offset.x
                                val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                                val index = (fraction * (renderPoints.size - 1)).roundToInt()
                                onPointInspected(renderPoints.getOrNull(index))
                            }
                        )
                    }
                    .pointerInput(renderPoints) {
                        detectDragGestures(
                            onDrag = { change, _ ->
                                change.consume()
                                touchX = change.position.x
                                val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
                                val index = (fraction * (renderPoints.size - 1)).roundToInt()
                                onPointInspected(renderPoints.getOrNull(index))
                            },
                            onDragEnd = {
                                // Keep inspected or clear after delay
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val paddingBottom = 28.dp.toPx()
                    val paddingTop = 20.dp.toPx()
                    val chartHeight = h - paddingTop - paddingBottom

                    // Draw Horizontal Grid Lines and Labels
                    val gridSteps = 4
                    for (i in 0..gridSteps) {
                        val frac = i.toFloat() / gridSteps
                        val y = paddingTop + chartHeight * (1f - frac)
                        val gridValue = minVal + valRange * frac

                        drawLine(
                            color = CyberBorder.copy(alpha = 0.5f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                        )

                        val labelText = when (metricType) {
                            ChartMetricType.TEMPERATURE -> String.format(Locale.US, "%.1f°", gridValue)
                            ChartMetricType.BATTERY -> String.format(Locale.US, "%.2fV", gridValue)
                        }

                        val measured = textMeasurer.measure(
                            text = labelText,
                            style = TextStyle(
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                        drawText(
                            textLayoutResult = measured,
                            topLeft = Offset(4.dp.toPx(), y - measured.size.height - 2.dp.toPx())
                        )
                    }

                    // Compute Point Coordinates
                    val coords = renderPoints.indices.map { i ->
                        val x = (i.toFloat() / (renderPoints.size - 1).coerceAtLeast(1)) * w
                        val norm = ((values[i] - minVal) / valRange).toFloat().coerceIn(0f, 1f)
                        val y = paddingTop + chartHeight * (1f - (norm * animationProgress.value))
                        Offset(x, y)
                    }

                    if (coords.isNotEmpty()) {
                        // Smooth Cubic Spline Path
                        val strokePath = Path()
                        val fillPath = Path()

                        strokePath.moveTo(coords[0].x, coords[0].y)
                        fillPath.moveTo(coords[0].x, h - paddingBottom)
                        fillPath.lineTo(coords[0].x, coords[0].y)

                        for (i in 0 until coords.size - 1) {
                            val p0 = if (i > 0) coords[i - 1] else coords[i]
                            val p1 = coords[i]
                            val p2 = coords[i + 1]
                            val p3 = if (i + 2 < coords.size) coords[i + 2] else p2

                            val cp1x = p1.x + (p2.x - p0.x) / 6f
                            val cp1y = p1.y + (p2.y - p0.y) / 6f
                            val cp2x = p2.x - (p3.x - p1.x) / 6f
                            val cp2y = p2.y - (p3.y - p1.y) / 6f

                            strokePath.cubicTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y)
                            fillPath.cubicTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y)
                        }

                        fillPath.lineTo(coords.last().x, h - paddingBottom)
                        fillPath.close()

                        // Gradient fill underneath curve
                        val fillGradient = Brush.verticalGradient(
                            colors = listOf(
                                if (metricType == ChartMetricType.TEMPERATURE) HeatOrange.copy(alpha = 0.35f) else CyberTeal.copy(alpha = 0.35f),
                                if (metricType == ChartMetricType.TEMPERATURE) HeatOrange.copy(alpha = 0.05f) else CyberTeal.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            startY = paddingTop,
                            endY = h - paddingBottom
                        )
                        drawPath(path = fillPath, brush = fillGradient)

                        // Main Stroke Line
                        val strokeBrush = Brush.horizontalGradient(
                            colors = listOf(
                                if (metricType == ChartMetricType.TEMPERATURE) HeatOrange else CyberTeal,
                                if (metricType == ChartMetricType.TEMPERATURE) Color(0xFFFF9E0B) else Color(0xFF38BDF8)
                            )
                        )
                        drawPath(
                            path = strokePath,
                            brush = strokeBrush,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Highlight Peak Marker on Chart
                        val peakCoord = coords[peakIndex]
                        drawCircle(
                            color = ChartPeakPoint.copy(alpha = 0.3f),
                            radius = 9.dp.toPx(),
                            center = peakCoord
                        )
                        drawCircle(
                            color = ChartPeakPoint,
                            radius = 5.dp.toPx(),
                            center = peakCoord
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.dp.toPx(),
                            center = peakCoord
                        )

                        // Highlight Min Marker on Chart
                        val minCoord = coords[minIndex]
                        drawCircle(
                            color = ChartMinPoint.copy(alpha = 0.3f),
                            radius = 9.dp.toPx(),
                            center = minCoord
                        )
                        drawCircle(
                            color = ChartMinPoint,
                            radius = 5.dp.toPx(),
                            center = minCoord
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.dp.toPx(),
                            center = minCoord
                        )

                        // Draw X-axis timestamps (First, Middle, Last)
                        val timeIndices = listOf(0, coords.size / 2, coords.size - 1)
                        for (idx in timeIndices) {
                            if (idx < renderPoints.size) {
                                val pt = renderPoints[idx]
                                val timeText = pt.formattedTime + " " + pt.formattedDate
                                val measured = textMeasurer.measure(
                                    text = timeText,
                                    style = TextStyle(
                                        color = TextSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                                val xPos = (coords[idx].x - measured.size.width / 2f).coerceIn(0f, w - measured.size.width)
                                drawText(
                                    textLayoutResult = measured,
                                    topLeft = Offset(xPos, h - paddingBottom + 8.dp.toPx())
                                )
                            }
                        }

                        // Draw interactive scrubbing guide line
                        if (inspectedPoint != null) {
                            val inspectedIdx = renderPoints.indexOf(inspectedPoint)
                            if (inspectedIdx >= 0 && inspectedIdx < coords.size) {
                                val activeCoord = coords[inspectedIdx]
                                drawLine(
                                    color = Color.White.copy(alpha = 0.7f),
                                    start = Offset(activeCoord.x, paddingTop),
                                    end = Offset(activeCoord.x, h - paddingBottom),
                                    strokeWidth = 1.5.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 6.dp.toPx(),
                                    center = activeCoord
                                )
                                drawCircle(
                                    color = if (metricType == ChartMetricType.TEMPERATURE) HeatOrange else CyberTeal,
                                    radius = 4.dp.toPx(),
                                    center = activeCoord
                                )
                            }
                        }
                    }
                }
            }

            // Real-time Scrubbing / Inspected Details Card
            if (inspectedPoint != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberSurfaceElevated)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SEÇİLEN AN: ${inspectedPoint.dateTimeStr}",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = String.format(Locale.US, "%.1f°C", inspectedPoint.temperature),
                                color = HeatOrange,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = String.format(Locale.US, "%.2fV  •  %%%d", inspectedPoint.voltage, inspectedPoint.batteryPercent),
                                color = CyberTeal,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    if (inspectedPoint.isCharging) {
                        Text(
                            text = "⚡ ŞARJDA",
                            color = Color(0xFFFACC15),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Noktasal değer ve saat için grafiğe basılı tutun",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
