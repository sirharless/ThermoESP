package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors - High Tech Cyber IoT
val CyberDarkBackground = Color(0xFF090D16)
val CyberSurface = Color(0xFF111827)
val CyberSurfaceCard = Color(0xFF162032)
val CyberSurfaceElevated = Color(0xFF1E293B)
val CyberBorder = Color(0xFF2E3D52)

val CyberTeal = Color(0xFF06B6D4)
val CyberTealLight = Color(0xFF67E8F9)
val CyberTealDark = Color(0xFF0891B2)

val HeatOrange = Color(0xFFFF6B00)
val HeatOrangeLight = Color(0xFFFFA05C)
val HeatRed = Color(0xFFEF4444)
val CoolBlue = Color(0xFF38BDF8)
val DeepCoolBlue = Color(0xFF0284C7)

val BatteryGreen = Color(0xFF10B981)
val BatteryGreenLight = Color(0xFF34D399)
val BatteryCharging = Color(0xFFFACC15)
val WarningAmber = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Chart Specific Accents
val ChartLineGradientStart = Color(0xFFFF5722)
val ChartLineGradientEnd = Color(0xFF06B6D4)
val ChartPeakPoint = Color(0xFFFF3D00)
val ChartMinPoint = Color(0xFF00E5FF)
