package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChartStatistics
import com.example.data.model.GuncelData
import com.example.data.model.HataLogItem
import com.example.data.model.TelemetryPoint
import com.example.data.model.TimeRangeFilter
import com.example.data.repository.EspTelemetryRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ChartMetricType {
    TEMPERATURE,
    BATTERY
}

enum class NavigationTab {
    DASHBOARD,
    ANALYTICS,
    DEVELOPER
}

data class MainUiState(
    val guncel: GuncelData = GuncelData(),
    val allPoints: List<TelemetryPoint> = emptyList(),
    val filteredPoints: List<TelemetryPoint> = emptyList(),
    val chartStats: ChartStatistics = ChartStatistics(),
    val selectedFilter: TimeRangeFilter = TimeRangeFilter.ONE_DAY,
    val selectedMetric: ChartMetricType = ChartMetricType.TEMPERATURE,
    val inspectedPoint: TelemetryPoint? = null,
    val hatalar: List<HataLogItem> = emptyList(),
    val latestHata: HataLogItem? = null,
    val latestHataRelativeTime: String = "",
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val lastRefreshTimeStr: String = "",
    val errorMessage: String? = null,
    val activeTab: NavigationTab = NavigationTab.DASHBOARD,
    // Developer console states
    val isSimulationMode: Boolean = false,
    val customBaseUrl: String = "",
    val customAuthToken: String = "",
    val devTestEndpointResult: String = "",
    val devTestStatusCode: Int = 0,
    val isDevTesting: Boolean = false,
    val autoRefreshSeconds: Int = 30 // 0 = off, 10, 30, 60
)

class MainViewModel(
    private val repository: EspTelemetryRepository = EspTelemetryRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        MainUiState(
            customBaseUrl = repository.baseUrl,
            customAuthToken = repository.authToken
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var autoRefreshJob: Job? = null

    init {
        loadData(isInitial = true)
        startAutoRefresh()
    }

    fun setTab(tab: NavigationTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun setTimeFilter(filter: TimeRangeFilter) {
        _uiState.update { current ->
            val filtered = repository.filterPoints(current.allPoints, filter)
            val stats = repository.computeStatistics(filtered)
            current.copy(
                selectedFilter = filter,
                filteredPoints = filtered,
                chartStats = stats,
                inspectedPoint = null // reset hover
            )
        }
    }

    fun setChartMetric(metric: ChartMetricType) {
        _uiState.update { it.copy(selectedMetric = metric, inspectedPoint = null) }
    }

    fun setInspectedPoint(point: TelemetryPoint?) {
        _uiState.update { it.copy(inspectedPoint = point) }
    }

    fun toggleSimulationMode(enabled: Boolean) {
        repository.isSimulationMode = enabled
        _uiState.update { it.copy(isSimulationMode = enabled) }
        loadData(isInitial = false)
    }

    fun updateConnectionSettings(url: String, token: String) {
        repository.baseUrl = url.trim()
        repository.authToken = token.trim()
        _uiState.update {
            it.copy(
                customBaseUrl = url.trim(),
                customAuthToken = token.trim()
            )
        }
        loadData(isInitial = false)
    }

    fun resetConnectionSettings() {
        repository.baseUrl = com.example.data.api.FirebaseApiClient.DEFAULT_BASE_URL
        repository.authToken = com.example.data.api.FirebaseApiClient.DEFAULT_AUTH_TOKEN
        _uiState.update {
            it.copy(
                customBaseUrl = repository.baseUrl,
                customAuthToken = repository.authToken
            )
        }
        loadData(isInitial = false)
    }

    fun setAutoRefreshInterval(seconds: Int) {
        _uiState.update { it.copy(autoRefreshSeconds = seconds) }
        startAutoRefresh()
    }

    fun testEndpoint(endpointName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isDevTesting = true) }
            val (code, response) = repository.testEndpoint(endpointName)
            _uiState.update {
                it.copy(
                    isDevTesting = false,
                    devTestStatusCode = code,
                    devTestEndpointResult = response
                )
            }
        }
    }

    fun refreshData() {
        loadData(isInitial = false)
    }

    private fun loadData(isInitial: Boolean) {
        viewModelScope.launch {
            if (isInitial) {
                _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            } else {
                _uiState.update { it.copy(isRefreshing = true, errorMessage = null) }
            }

            try {
                val guncelResult = repository.getGuncelData()
                val pointsResult = repository.getAllTelemetryPoints()
                val hatalarResult = repository.getHatalar()

                val guncel = guncelResult.getOrNull() ?: _uiState.value.guncel
                val points = pointsResult.getOrNull() ?: _uiState.value.allPoints
                val hatalar = hatalarResult.getOrNull() ?: _uiState.value.hatalar

                val filtered = repository.filterPoints(points, _uiState.value.selectedFilter)
                val stats = repository.computeStatistics(filtered)

                val latestHata = hatalar.firstOrNull()
                val latestHataTime = latestHata?.getRelativeTimeDescription() ?: ""

                val nowTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    .format(java.util.Date())

                _uiState.update {
                    it.copy(
                        guncel = guncel,
                        allPoints = points,
                        filteredPoints = filtered,
                        chartStats = stats,
                        hatalar = hatalar,
                        latestHata = latestHata,
                        latestHataRelativeTime = latestHataTime,
                        isLoading = false,
                        isRefreshing = false,
                        lastRefreshTimeStr = nowTime,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isRefreshing = false,
                        errorMessage = "Veri alınamadı: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    private fun startAutoRefresh() {
        autoRefreshJob?.cancel()
        val interval = _uiState.value.autoRefreshSeconds
        if (interval <= 0) return

        autoRefreshJob = viewModelScope.launch {
            while (isActive) {
                delay(interval * 1000L)
                loadData(isInitial = false)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        autoRefreshJob?.cancel()
    }
}
