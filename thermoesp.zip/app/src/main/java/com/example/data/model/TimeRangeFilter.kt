package com.example.data.model

enum class TimeRangeCategory(val title: String) {
    HOURLY("Saatlik"),
    DAILY("Günlük"),
    WEEKLY("Haftalık"),
    MONTHLY("Aylık"),
    YEARLY("Yıllık")
}

enum class TimeRangeFilter(
    val label: String,
    val shortLabel: String,
    val durationSeconds: Long,
    val category: TimeRangeCategory
) {
    THREE_HOURS("3 Saat", "3S", 3 * 3600L, TimeRangeCategory.HOURLY),
    SIX_HOURS("6 Saat", "6S", 6 * 3600L, TimeRangeCategory.HOURLY),
    TWELVE_HOURS("12 Saat", "12S", 12 * 3600L, TimeRangeCategory.HOURLY),
    ONE_DAY("1 Gün", "1G", 24 * 3600L, TimeRangeCategory.DAILY),
    THREE_DAYS("3 Gün", "3G", 3 * 24 * 3600L, TimeRangeCategory.DAILY),
    ONE_WEEK("1 Hafta", "1H", 7 * 24 * 3600L, TimeRangeCategory.WEEKLY),
    TWO_WEEKS("2 Hafta", "2H", 14 * 24 * 3600L, TimeRangeCategory.WEEKLY),
    THREE_WEEKS("3 Hafta", "3H", 21 * 24 * 3600L, TimeRangeCategory.WEEKLY),
    ONE_MONTH("1 Ay", "1A", 30 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    TWO_MONTHS("2 Ay", "2A", 60 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    THREE_MONTHS("3 Ay", "3A", 90 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    FOUR_MONTHS("4 Ay", "4A", 120 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    FIVE_MONTHS("5 Ay", "5A", 150 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    SIX_MONTHS("6 Ay", "6A", 180 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    SEVEN_MONTHS("7 Ay", "7A", 210 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    EIGHT_MONTHS("8 Ay", "8A", 240 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    NINE_MONTHS("9 Ay", "9A", 270 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    TEN_MONTHS("10 Ay", "10A", 300 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    ELEVEN_MONTHS("11 Ay", "11A", 330 * 24 * 3600L, TimeRangeCategory.MONTHLY),
    ONE_YEAR("1 Yıl", "1Y", 365 * 24 * 3600L, TimeRangeCategory.YEARLY),
    ALL("Tümü", "Hepsi", Long.MAX_VALUE, TimeRangeCategory.YEARLY);

    companion object {
        fun getPrimaryQuickFilters(): List<TimeRangeFilter> {
            return listOf(
                THREE_HOURS,
                SIX_HOURS,
                TWELVE_HOURS,
                ONE_DAY,
                THREE_DAYS,
                ONE_WEEK,
                TWO_WEEKS,
                THREE_WEEKS,
                ONE_MONTH,
                THREE_MONTHS,
                SIX_MONTHS,
                ONE_YEAR
            )
        }
    }
}
