package com.example.data.api

import com.example.data.model.GuncelData
import com.example.data.model.HataLogItem
import com.example.data.model.PilLogItem
import com.example.data.model.SicaklikLogItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class FirebaseApiClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        const val DEFAULT_BASE_URL = "https://hizlisicaklik-default-rtdb.europe-west1.firebasedatabase.app"
        const val DEFAULT_AUTH_TOKEN = "1OTr2vLqRzxkOT7u6QqBW07aPWZukTassOM4h2JL"
    }

    suspend fun fetchGuncel(
        baseUrl: String = DEFAULT_BASE_URL,
        authToken: String = DEFAULT_AUTH_TOKEN
    ): Result<GuncelData> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = baseUrl.trim().removeSuffix("/")
            val url = "$cleanBase/guncel.json?auth=${authToken.trim()}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: ${response.message}"))
            }

            val body = response.body?.string() ?: ""
            if (body.isEmpty() || body == "null") {
                return@withContext Result.success(GuncelData(rawJson = body))
            }

            val json = JSONObject(body)
            val sensorHata = json.optBoolean("sensor_hata", false)
            val voltaj = json.optDouble("voltaj", 0.0)
            val yuzde = json.optInt("yuzde", 0)
            val sarjda = json.optBoolean("sarjda", false)
            val tarihSaat = json.optString("tarih_saat", "")
            val timestamp = json.optLong("timestamp", 0L)

            // Handle derece which can be a number or "Hata"
            var dereceDouble: Double? = null
            var dereceStr = "--"
            if (json.has("derece") && !json.isNull("derece")) {
                val rawVal = json.get("derece")
                if (rawVal is Number) {
                    dereceDouble = rawVal.toDouble()
                    dereceStr = String.format("%.1f", dereceDouble)
                } else {
                    val str = rawVal.toString()
                    val parsed = str.toDoubleOrNull()
                    if (parsed != null) {
                        dereceDouble = parsed
                        dereceStr = String.format("%.1f", parsed)
                    } else {
                        dereceStr = str
                    }
                }
            }

            Result.success(
                GuncelData(
                    derece = dereceDouble,
                    dereceText = dereceStr,
                    sensorHata = sensorHata,
                    voltaj = voltaj,
                    yuzde = yuzde,
                    sarjda = sarjda,
                    tarihSaat = tarihSaat,
                    timestamp = timestamp,
                    rawJson = body
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchSicaklikLoglar(
        baseUrl: String = DEFAULT_BASE_URL,
        authToken: String = DEFAULT_AUTH_TOKEN
    ): Result<List<SicaklikLogItem>> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = baseUrl.trim().removeSuffix("/")
            val url = "$cleanBase/loglar/sicaklik.json?auth=${authToken.trim()}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: ${response.message}"))
            }

            val body = response.body?.string() ?: ""
            if (body.isEmpty() || body == "null" || body == "{}") {
                return@withContext Result.success(emptyList())
            }

            val list = mutableListOf<SicaklikLogItem>()
            val root = JSONObject(body)
            val keys = root.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val ts = key.toLongOrNull() ?: 0L
                val itemObj = root.optJSONObject(key)
                if (itemObj != null) {
                    val derece = itemObj.optDouble("derece", 0.0)
                    val tarihSaat = itemObj.optString("tarih_saat", "")
                    list.add(SicaklikLogItem(timestamp = ts, derece = derece, tarihSaat = tarihSaat))
                }
            }
            list.sortBy { it.timestamp }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchPilLoglar(
        baseUrl: String = DEFAULT_BASE_URL,
        authToken: String = DEFAULT_AUTH_TOKEN
    ): Result<List<PilLogItem>> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = baseUrl.trim().removeSuffix("/")
            val url = "$cleanBase/loglar/pil.json?auth=${authToken.trim()}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: ${response.message}"))
            }

            val body = response.body?.string() ?: ""
            if (body.isEmpty() || body == "null" || body == "{}") {
                return@withContext Result.success(emptyList())
            }

            val list = mutableListOf<PilLogItem>()
            val root = JSONObject(body)
            val keys = root.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val ts = key.toLongOrNull() ?: 0L
                val itemObj = root.optJSONObject(key)
                if (itemObj != null) {
                    val voltaj = itemObj.optDouble("voltaj", 0.0)
                    val yuzde = itemObj.optInt("yuzde", 0)
                    val sarjda = itemObj.optBoolean("sarjda", false)
                    val tarihSaat = itemObj.optString("tarih_saat", "")
                    list.add(
                        PilLogItem(
                            timestamp = ts,
                            voltaj = voltaj,
                            yuzde = yuzde,
                            sarjda = sarjda,
                            tarihSaat = tarihSaat
                        )
                    )
                }
            }
            list.sortBy { it.timestamp }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchHatalar(
        baseUrl: String = DEFAULT_BASE_URL,
        authToken: String = DEFAULT_AUTH_TOKEN
    ): Result<List<HataLogItem>> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = baseUrl.trim().removeSuffix("/")
            val url = "$cleanBase/hatalar.json?auth=${authToken.trim()}"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP ${response.code}: ${response.message}"))
            }

            val body = response.body?.string() ?: ""
            if (body.isEmpty() || body == "null" || body == "{}") {
                return@withContext Result.success(emptyList())
            }

            val list = mutableListOf<HataLogItem>()
            val root = JSONObject(body)
            val keys = root.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val ts = key.toLongOrNull() ?: 0L
                val itemObj = root.optJSONObject(key)
                if (itemObj != null) {
                    val hataDetayi = itemObj.optString("hata_detayi", "[Bilinmeyen Hata]")
                    val sicaklik = itemObj.optDouble("sicaklik", -127.0)
                    val voltaj = itemObj.optDouble("voltaj", 0.0)
                    val tarihSaat = itemObj.optString("tarih_saat", "")
                    list.add(
                        HataLogItem(
                            id = key,
                            timestamp = ts,
                            hataDetayi = hataDetayi,
                            sicaklik = sicaklik,
                            voltaj = voltaj,
                            tarihSaat = tarihSaat
                        )
                    )
                }
            }
            // Sort newest first
            list.sortByDescending { it.timestamp }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun testEndpointRaw(url: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        try {
            val startTime = System.currentTimeMillis()
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val latency = System.currentTimeMillis() - startTime
            val body = response.body?.string() ?: ""
            Pair(response.code, "Gecikme: ${latency}ms\n\n$body")
        } catch (e: Exception) {
            Pair(-1, "Hata: ${e.localizedMessage}")
        }
    }
}
