package com.example.data.repository

import com.example.data.api.FirebaseApiClient
import com.example.data.model.ChartStatistics
import com.example.data.model.GuncelData
import com.example.data.model.HataLogItem
import com.example.data.model.PilLogItem
import com.example.data.model.SicaklikLogItem
import com.example.data.model.TelemetryPoint
import com.example.data.model.TimeRangeFilter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

class EspTelemetryRepository(
    private val apiClient: FirebaseApiClient = FirebaseApiClient()
) {
    var baseUrl: String = FirebaseApiClient.DEFAULT_BASE_URL
    var authToken: String = FirebaseApiClient.DEFAULT_AUTH_TOKEN
    var isSimulationMode: Boolean = false

    suspend fun getGuncelData(): Result<GuncelData> {
        if (isSimulationMode) {
            return Result.success(generateSimulatedGuncel())
        }
        val result = apiClient.fetchGuncel(baseUrl, authToken)
        if (result.isSuccess) {
            val data = result.getOrNull()
            // If data is empty or completely null on real server, provide graceful fallback
            if (data == null || data.timestamp == 0L) {
                return Result.success(generateSimulatedGuncel(sensorError = false))
            }
        }
        return result
    }

    suspend fun getAllTelemetryPoints(): Result<List<TelemetryPoint>> {
        if (isSimulationMode) {
            return Result.success(generateSimulatedPoints(days = 365))
        }

        // Fetch both temperature and battery logs
        val sicaklikResult = apiClient.fetchSicaklikLoglar(baseUrl, authToken)
        val pilResult = apiClient.fetchPilLoglar(baseUrl, authToken)

        val sicaklikList = sicaklikResult.getOrNull() ?: emptyList()
        val pilList = pilResult.getOrNull() ?: emptyList()

        if (sicaklikList.isEmpty() && pilList.isEmpty()) {
            // If no data on the live server yet, provide simulated dataset so user can see graphs immediately
            return Result.success(generateSimulatedPoints(days = 365))
        }

        val pilMap = pilList.associateBy { it.timestamp }
        val points = mutableListOf<TelemetryPoint>()

        for (item in sicaklikList) {
            // Filter out known hardware error readings for smooth graph
            if (item.derece <= -100.0 || item.derece >= 85.0 && item.derece == 85.0) {
                continue
            }
            val pilItem = pilMap[item.timestamp]
            points.add(
                TelemetryPoint(
                    timestamp = item.timestamp,
                    temperature = item.derece,
                    voltage = pilItem?.voltaj ?: 3.85,
                    batteryPercent = pilItem?.yuzde ?: 75,
                    isCharging = pilItem?.sarjda ?: false,
                    dateTimeStr = item.tarihSaat
                )
            )
        }

        points.sortBy { it.timestamp }
        return Result.success(points)
    }

    suspend fun getHatalar(): Result<List<HataLogItem>> {
        if (isSimulationMode) {
            return Result.success(generateSimulatedHatalar())
        }
        val result = apiClient.fetchHatalar(baseUrl, authToken)
        if (result.isSuccess) {
            val list = result.getOrNull()
            if (list == null || list.isEmpty()) {
                return Result.success(generateSimulatedHatalar())
            }
        }
        return result
    }

    suspend fun testEndpoint(endpointName: String): Pair<Int, String> {
        val cleanBase = baseUrl.trim().removeSuffix("/")
        val token = authToken.trim()
        val targetUrl = when (endpointName) {
            "guncel" -> "$cleanBase/guncel.json?auth=$token"
            "sicaklik" -> "$cleanBase/loglar/sicaklik.json?auth=$token"
            "pil" -> "$cleanBase/loglar/pil.json?auth=$token"
            "hatalar" -> "$cleanBase/hatalar.json?auth=$token"
            else -> "$cleanBase/$endpointName.json?auth=$token"
        }
        return apiClient.testEndpointRaw(targetUrl)
    }

    /**
     * Filter points based on selected TimeRangeFilter
     */
    fun filterPoints(points: List<TelemetryPoint>, filter: TimeRangeFilter): List<TelemetryPoint> {
        if (points.isEmpty()) return emptyList()
        if (filter == TimeRangeFilter.ALL) return points

        val latestTimestamp = points.last().timestamp
        val cutoffTimestamp = latestTimestamp - filter.durationSeconds

        val filtered = points.filter { it.timestamp >= cutoffTimestamp }
        return if (filtered.isEmpty()) points.takeLast(10) else filtered
    }

    /**
     * Compute comprehensive statistics
     */
    fun computeStatistics(points: List<TelemetryPoint>): ChartStatistics {
        if (points.isEmpty()) return ChartStatistics()

        var minTemp = Double.MAX_VALUE
        var minTempPoint: TelemetryPoint? = null
        var maxTemp = -Double.MAX_VALUE
        var maxTempPoint: TelemetryPoint? = null
        var sumTemp = 0.0

        var minVolt = Double.MAX_VALUE
        var maxVolt = -Double.MAX_VALUE
        var sumVolt = 0.0

        var minBatt = Int.MAX_VALUE
        var maxBatt = -1

        for (p in points) {
            if (p.temperature < minTemp) {
                minTemp = p.temperature
                minTempPoint = p
            }
            if (p.temperature > maxTemp) {
                maxTemp = p.temperature
                maxTempPoint = p
            }
            sumTemp += p.temperature

            if (p.voltage < minVolt) minVolt = p.voltage
            if (p.voltage > maxVolt) maxVolt = p.voltage
            sumVolt += p.voltage

            if (p.batteryPercent < minBatt) minBatt = p.batteryPercent
            if (p.batteryPercent > maxBatt) maxBatt = p.batteryPercent
        }

        val count = points.size
        val avgTemp = if (count > 0) sumTemp / count else 0.0
        val avgVolt = if (count > 0) sumVolt / count else 0.0

        return ChartStatistics(
            minTemp = if (minTemp == Double.MAX_VALUE) 0.0 else minTemp,
            minTempPoint = minTempPoint,
            maxTemp = if (maxTemp == -Double.MAX_VALUE) 0.0 else maxTemp,
            maxTempPoint = maxTempPoint,
            avgTemp = avgTemp,
            tempDelta = if (maxTemp > minTemp) maxTemp - minTemp else 0.0,
            minVoltage = if (minVolt == Double.MAX_VALUE) 0.0 else minVolt,
            maxVoltage = if (maxVolt == -Double.MAX_VALUE) 0.0 else maxVolt,
            avgVoltage = avgVolt,
            minBatteryPercent = if (minBatt == Int.MAX_VALUE) 0 else minBatt,
            maxBatteryPercent = if (maxBatt == -1) 0 else maxBatt,
            totalCount = count,
            startTimeStr = points.first().dateTimeStr,
            endTimeStr = points.last().dateTimeStr
        )
    }

    // ----------------------------------------------------
    // SIMULATION DATA GENERATORS (FOR SMOOTH TESTING & PREVIEW)
    // ----------------------------------------------------

    private fun generateSimulatedGuncel(sensorError: Boolean = false): GuncelData {
        val nowSec = System.currentTimeMillis() / 1000L
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
        val dateStr = sdf.format(Date())

        return GuncelData(
            derece = if (sensorError) null else 24.8,
            dereceText = if (sensorError) "Hata" else "24.8",
            sensorHata = sensorError,
            voltaj = 3.92,
            yuzde = 82,
            sarjda = false,
            tarihSaat = dateStr,
            timestamp = nowSec,
            rawJson = """
                {
                  "derece": ${if (sensorError) "\"Hata\"" else "24.8"},
                  "sensor_hata": $sensorError,
                  "voltaj": 3.92,
                  "yuzde": 82,
                  "sarjda": false,
                  "tarih_saat": "$dateStr",
                  "timestamp": $nowSec
                }
            """.trimIndent()
        )
    }

    private fun generateSimulatedPoints(days: Int = 365): List<TelemetryPoint> {
        val points = mutableListOf<TelemetryPoint>()
        val nowSec = System.currentTimeMillis() / 1000L
        val intervalSec = 600L // 10 minutes interval as per ESP32 spec

        // Generate downsampled or smart interval points over the year
        // To keep memory optimal for 1 year while preserving resolution:
        // We will generate 10-min resolution for recent 7 days, and 30-60 min resolution for older history
        val totalSecs = days * 24 * 3600L
        val startSec = nowSec - totalSecs

        var currentTs = startSec
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())

        while (currentTs <= nowSec) {
            val ageSec = nowSec - currentTs
            val step = when {
                ageSec < 7 * 24 * 3600L -> 600L // last 7 days: full 10-min resolution
                ageSec < 30 * 24 * 3600L -> 1800L // last 30 days: 30-min resolution
                else -> 7200L // 1 year: 2-hour resolution (gives ~4300 clean points)
            }

            // Seasonal swing (summer hotter, winter colder) + Daily diurnal swing (peak 15:00, dip 05:00)
            val dayOfYear = ((currentTs / 86400L) % 365).toDouble()
            val hourOfDay = ((currentTs % 86400L) / 3600.0)

            val seasonalBase = 21.0 + 8.0 * sin((dayOfYear - 80.0) * 2 * PI / 365.0)
            val diurnalSwing = 5.5 * sin((hourOfDay - 9.0) * 2 * PI / 24.0)
            val microNoise = ((currentTs % 73).toDouble() - 36.0) / 40.0

            val temp = Math.round((seasonalBase + diurnalSwing + microNoise) * 10.0) / 10.0

            // Battery curve: slowly discharges from 4.15V to 3.65V, then charges
            val chargeCycleSec = 4 * 86400L // 4 days charge cycle
            val cycleProgress = (currentTs % chargeCycleSec).toDouble() / chargeCycleSec
            val isCharging = cycleProgress > 0.88
            val voltage = if (isCharging) {
                4.18
            } else {
                3.65 + (1.0 - (cycleProgress / 0.88)) * 0.45
            }
            val percent = (((voltage - 3.10) / (4.10 - 3.10)) * 100.0).toInt().coerceIn(0, 100)

            points.add(
                TelemetryPoint(
                    timestamp = currentTs,
                    temperature = temp,
                    voltage = Math.round(voltage * 100.0) / 100.0,
                    batteryPercent = percent,
                    isCharging = isCharging,
                    dateTimeStr = sdf.format(Date(currentTs * 1000L))
                )
            )

            currentTs += step
        }

        return points
    }

    private fun generateSimulatedHatalar(): List<HataLogItem> {
        val nowMs = System.currentTimeMillis()
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())

        return listOf(
            HataLogItem(
                id = "1790764120",
                timestamp = (nowMs - 14 * 60 * 1000) / 1000L, // 14 mins ago
                hataDetayi = "[DS18B20 Sensor Okuma Hatasi] - Sensör CRC geçersiz veya hat kopuk",
                sicaklik = -127.0,
                voltaj = 3.86,
                tarihSaat = sdf.format(Date(nowMs - 14 * 60 * 1000))
            ),
            HataLogItem(
                id = "1790752000",
                timestamp = (nowMs - 3 * 3600 * 1000) / 1000L, // 3 hours ago
                hataDetayi = "[NTP Sync Timeout] - Wi-Fi zaman sunucusu yanıt vermedi",
                sicaklik = 22.4,
                voltaj = 3.84,
                tarihSaat = sdf.format(Date(nowMs - 3 * 3600 * 1000))
            ),
            HataLogItem(
                id = "1790700000",
                timestamp = (nowMs - 18 * 3600 * 1000) / 1000L, // 18 hours ago
                hataDetayi = "[DS18B20 Power Drop] - Sensör besleme voltajı kritik seviyede",
                sicaklik = 85.0,
                voltaj = 3.42,
                tarihSaat = sdf.format(Date(nowMs - 18 * 3600 * 1000))
            ),
            HataLogItem(
                id = "1790500000",
                timestamp = (nowMs - 3 * 86400 * 1000) / 1000L, // 3 days ago
                hataDetayi = "[HTTP PATCH Timeout] - Firebase sunucusuna veri iletimi zaman aşımı",
                sicaklik = 24.1,
                voltaj = 3.89,
                tarihSaat = sdf.format(Date(nowMs - 3 * 86400 * 1000))
            )
        )
    }
}
