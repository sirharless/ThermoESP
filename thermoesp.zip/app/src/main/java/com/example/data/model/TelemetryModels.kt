package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Current live status from /guncel.json
 */
data class GuncelData(
    val derece: Double? = null,
    val dereceText: String = "--",
    val sensorHata: Boolean = false,
    val voltaj: Double = 0.0,
    val yuzde: Int = 0,
    val sarjda: Boolean = false,
    val tarihSaat: String = "",
    val timestamp: Long = 0L,
    val rawJson: String = ""
) {
    val isFaulty: Boolean
        get() = sensorHata || derece == null || derece <= -100.0 || derece >= 85.0 && sensorHata
}

/**
 * Temperature log item from /loglar/sicaklik.json
 */
data class SicaklikLogItem(
    val timestamp: Long,
    val derece: Double,
    val tarihSaat: String
)

/**
 * Battery log item from /loglar/pil.json
 */
data class PilLogItem(
    val timestamp: Long,
    val voltaj: Double,
    val yuzde: Int,
    val sarjda: Boolean,
    val tarihSaat: String
)

/**
 * System error log item from /hatalar.json
 */
data class HataLogItem(
    val id: String,
    val timestamp: Long,
    val hataDetayi: String,
    val sicaklik: Double,
    val voltaj: Double,
    val tarihSaat: String
) {
    /**
     * Relative time string e.g. "12 dakika önce", "2 saat önce", "3 gün önce"
     */
    fun getRelativeTimeDescription(referenceTimeMs: Long = System.currentTimeMillis()): String {
        val targetMs = if (timestamp < 100_000_000_000L) timestamp * 1000L else timestamp
        val diffMs = referenceTimeMs - targetMs
        if (diffMs < 0) return tarihSaat

        val minutes = diffMs / (60 * 1000)
        val hours = diffMs / (60 * 60 * 1000)
        val days = diffMs / (24 * 60 * 60 * 1000)

        return when {
            minutes < 1 -> "Az önce"
            minutes < 60 -> "$minutes dakika önce"
            hours < 24 -> "$hours saat önce"
            days < 7 -> "$days gün önce"
            days < 30 -> "${days / 7} hafta önce"
            else -> "${days / 30} ay önce"
        }
    }
}

/**
 * Combined telemetry point for plotting charts and synchronized views
 */
data class TelemetryPoint(
    val timestamp: Long, // unix seconds
    val temperature: Double,
    val voltage: Double,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val dateTimeStr: String
) {
    val formattedTime: String
        get() {
            return try {
                val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                sdf.format(Date(if (timestamp < 100_000_000_000L) timestamp * 1000L else timestamp))
            } catch (e: Exception) {
                if (dateTimeStr.length >= 16) dateTimeStr.substring(11, 16) else dateTimeStr
            }
        }

    val formattedDate: String
        get() {
            return try {
                val sdf = SimpleDateFormat("dd MMM", Locale("tr"))
                sdf.format(Date(if (timestamp < 100_000_000_000L) timestamp * 1000L else timestamp))
            } catch (e: Exception) {
                if (dateTimeStr.length >= 10) dateTimeStr.substring(0, 10) else dateTimeStr
            }
        }
}

/**
 * Statistics calculated over a filtered set of telemetry points
 */
data class ChartStatistics(
    val minTemp: Double = 0.0,
    val minTempPoint: TelemetryPoint? = null,
    val maxTemp: Double = 0.0,
    val maxTempPoint: TelemetryPoint? = null,
    val avgTemp: Double = 0.0,
    val tempDelta: Double = 0.0,
    val minVoltage: Double = 0.0,
    val maxVoltage: Double = 0.0,
    val avgVoltage: Double = 0.0,
    val minBatteryPercent: Int = 0,
    val maxBatteryPercent: Int = 0,
    val totalCount: Int = 0,
    val startTimeStr: String = "",
    val endTimeStr: String = ""
)
